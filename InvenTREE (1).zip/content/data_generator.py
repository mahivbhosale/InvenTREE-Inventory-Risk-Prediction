import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import os

os.makedirs('data', exist_ok=True)

np.random.seed(42)

def generate_data(num_items=50, num_stores=5, days=365):
    start = datetime.today() - timedelta(days=days)
    rows = []
    for store in range(1, num_stores+1):
        for item in range(1, num_items+1):
            base_demand = max(1, int(np.random.poisson(5)))
            seasonality = np.random.choice([0.7, 1.0, 1.3])
            lead_time = np.random.randint(1, 10)
            reorder_point = max(5, int(base_demand * lead_time * 0.8))
            on_hand = reorder_point + np.random.randint(0, 50)
            for d in range(days):
                date = (start + timedelta(days=d)).date()
                promotion = 1 if np.random.rand() < 0.05 else 0
                noise = np.random.normal(0, 1)
                qty = max(0, int(np.round(base_demand * seasonality * (1 + 0.5*promotion) + noise)))
                rows.append({
                    'store_id': f'S{store}',
                    'item_id': f'I{item}',
                    'date': pd.to_datetime(date),
                    'quantity_sold': qty,
                    'on_hand': on_hand,
                    'lead_time_days': lead_time,
                    'reorder_point': reorder_point,
                    'price': round(50 + np.random.rand()*200, 2),
                    'promotion': promotion
                })
    df = pd.DataFrame(rows)
    df.to_csv('data/inventory_data.csv', index=False)
    print('Saved data/inventory_data.csv with', len(df), 'rows')

if __name__ == '__main__':
    generate_data(num_items=80, num_stores=6, days=540)
