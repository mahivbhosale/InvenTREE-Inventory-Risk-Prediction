import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from preprocess import create_features_labels

def train():
    df = pd.read_pickle('/content/data/preprocessed.pkl')
    df, features, label_stockout, label_overstock = create_features_labels(df)

    X = df[features]
    y_stock = df[label_stockout]
    y_over = df[label_overstock]

    split_idx = int(0.8*len(df))
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_stock_train, y_stock_test = y_stock.iloc[:split_idx], y_stock.iloc[split_idx:]
    y_over_train, y_over_test = y_over.iloc[:split_idx], y_over.iloc[split_idx:]

    rf_stock = RandomForestClassifier(n_estimators=200, random_state=42)
    rf_stock.fit(X_train, y_stock_train)
    print('Stockout Report:\n', classification_report(y_stock_test, rf_stock.predict(X_test)))
    joblib.dump(rf_stock, '/content/rf_stockout.joblib')

    rf_over = RandomForestClassifier(n_estimators=200, random_state=43)
    rf_over.fit(X_train, y_over_train)
    print('Overstock Report:\n', classification_report(y_over_test, rf_over.predict(X_test)))
    joblib.dump(rf_over, '/content/rf_overstock.joblib')

if __name__ == '__main__':
    train()
