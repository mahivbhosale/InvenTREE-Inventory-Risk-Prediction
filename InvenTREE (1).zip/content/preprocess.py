import pandas as pd
import numpy as np

def create_features_labels(df, horizon_days=14):
    df = df.sort_values(['store_id','item_id','date']).copy()
    df['sales_7'] = df.groupby(['store_id','item_id'])['quantity_sold'].transform(lambda x: x.rolling(7, min_periods=1).sum())
    df['sales_14'] = df.groupby(['store_id','item_id'])['quantity_sold'].transform(lambda x: x.rolling(14, min_periods=1).sum())
    df['sales_30_mean'] = df.groupby(['store_id','item_id'])['quantity_sold'].transform(lambda x: x.rolling(30, min_periods=1).mean())
    df['sales_30_std'] = df.groupby(['store_id','item_id'])['quantity_sold'].transform(lambda x: x.rolling(30, min_periods=1).std().fillna(0))
    df['day_of_week'] = df['date'].dt.dayofweek

    def stockout_flag(group):
        q = group['quantity_sold'].values
        on = group['on_hand'].values
        n = len(q)
        flags = np.zeros(n, dtype=int)
        for i in range(n):
            cum = q[i+1:i+1+horizon_days].sum() if i+1 < n else 0
            flags[i] = 1 if cum > on[i] else 0
        return flags

    def overstock_flag(group):
        q = group['quantity_sold'].values
        on = group['on_hand'].values
        rp = group['reorder_point'].values
        n = len(q)
        flags = np.zeros(n, dtype=int)
        for i in range(n):
            future_sales = q[i+1:i+1+horizon_days].sum() if i+1 < n else 0
            projected = on[i] - future_sales
            flags[i] = 1 if projected > rp[i]*2 else 0
        return flags

    df['stockout'] = df.groupby(['store_id','item_id']).apply(stockout_flag).explode().astype(int).values
    df['overstock'] = df.groupby(['store_id','item_id']).apply(overstock_flag).explode().astype(int).values

    df = df.dropna()

    feature_cols = ['sales_7','sales_14','sales_30_mean','sales_30_std','on_hand','lead_time_days','reorder_point','price','promotion','day_of_week']

    return df, feature_cols, 'stockout', 'overstock'

if __name__ == '__main__':
    df = pd.read_csv('data/inventory_data.csv', parse_dates=['date'])
    df, features, out_s, out_o = create_features_labels(df)
    df.to_pickle('data/preprocessed.pkl')
    print('Preprocessed saved. Features:', features)
